define([`${localStorage['rsDebugUrl_xdjqdflgkexney'] || './build/js/app.38a5d7e8.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
