define([`${localStorage['rsDebugUrl_xdljp4lgndzu2s'] || 'https://localhost:9000/js/app.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
